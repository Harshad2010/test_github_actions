print("Check github actions Running App.py")

def add(a,b):
  result = a+b
  return result

if __name__ == "__main__":
  print("result", add(10,12))
